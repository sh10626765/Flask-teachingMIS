-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE TRIGGER deleteCourseCascade 
   ON school.dbo.course 
   instead of delete
AS 
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for trigger here
	declare @kh nchar(10)

	select @kh=kh from deleted
	delete from opencourse where kh=@kh
	delete from course where kh=@kh
END
go

