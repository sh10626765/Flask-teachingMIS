-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE TRIGGER [dbo].[checkOpenCourseTime] 
   ON  [school].[dbo].[opencourse] 
   instead of insert
AS 
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	
	declare @sksj nchar(50)
	declare @gh nchar(10)
	declare @xq nchar(50)
	declare @kh nchar(10)
	declare @rl int

    -- Insert statements for trigger here
	select @sksj=sksj,@gh=gh,@xq=xq,@kh=kh,@rl=rl
	from inserted
	if not exists (select * from opencourse
					where xq=@xq and gh=@gh and -- 一周内同一天  插入开课的xq、gh相同，时间有重叠
						(	SUBSTRING(sksj,3,1) = SUBSTRING(@sksj,3,1) and (
								(convert(int,SUBSTRING(@sksj,4,1)) >= convert(int,SUBSTRING(sksj,4,1)) and convert(int,SUBSTRING(@sksj,4,1)) <= convert(int,SUBSTRING(sksj,6,2))) or
								(convert(int,SUBSTRING(@sksj,6,2)) >= convert(int,SUBSTRING(sksj,4,1)) and convert(int,SUBSTRING(@sksj,6,2)) <= convert(int,SUBSTRING(sksj,6,2)))
							)
						)
					)
	begin

	insert dbo.opencourse(kh,xq,gh,sksj,rl,xkrs)
	values (@kh,@xq,@gh,@sksj,@rl,0)

	end
	else
	begin
	select @sksj=sksj,@xq=xq,@gh=gh from opencourse where xq=@xq and gh=@gh and -- 一周内同一天  插入开课的xq、gh相同，时间有重叠
						(	SUBSTRING(sksj,3,1) = SUBSTRING(@sksj,3,1) and (
								(convert(int,SUBSTRING(@sksj,4,1)) >= convert(int,SUBSTRING(sksj,4,1)) and convert(int,SUBSTRING(@sksj,4,1)) <= convert(int,SUBSTRING(sksj,6,2))) or
								(convert(int,SUBSTRING(@sksj,6,2)) >= convert(int,SUBSTRING(sksj,4,1)) and convert(int,SUBSTRING(@sksj,6,2)) <= convert(int,SUBSTRING(sksj,6,2)))
							)
						)
	RAISERROR('Time Conflict! Already exist %s, %s, %s.',16,1,@xq,@sksj,@gh)
	end
END
go

