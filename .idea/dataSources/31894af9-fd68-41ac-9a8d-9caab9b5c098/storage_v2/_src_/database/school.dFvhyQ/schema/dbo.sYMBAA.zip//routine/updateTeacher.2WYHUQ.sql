-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[updateTeacher]
	-- Add the parameters for the stored procedure here
	@gh nchar(10),
	@xb nchar(10),
	@xl nchar(10),
	@jbgz nchar(10),
	@yxh nchar(10),
	@pwd nchar(10),
	@csrq datetime
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
	update dbo.teacher set xb=@xb,xl=@xl,yxh=@yxh,pwd=@pwd,jbgz=@jbgz,csrq=@csrq
	where gh=@gh
END
go

