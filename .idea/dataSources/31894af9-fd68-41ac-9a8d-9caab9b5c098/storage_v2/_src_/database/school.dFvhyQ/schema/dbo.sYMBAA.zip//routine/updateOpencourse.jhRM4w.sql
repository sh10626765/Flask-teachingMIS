-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[updateOpencourse]
	-- Add the parameters for the stored procedure here
	@xq nvarchar(50),
	@kh nchar(10),
	@gh nchar(10),
	@sksj nvarchar(50),
	@rl int
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
	update dbo.opencourse set gh=@gh,sksj=@sksj,rl=@rl
	where xq=@xq and kh=@kh
END
go

