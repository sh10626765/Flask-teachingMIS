-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE dbo.getStudentCourses
	-- Add the parameters for the stored procedure here
	@xh nchar(10)
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
	select exam.xq, exam.kh, course.km, exam.gh, teacher.xm, opencourse.sksj
	from course, exam, opencourse, teacher
	where course.kh = exam.kh and
			exam.gh = teacher.gh and
			exam.kh = opencourse.kh and
			exam.gh = opencourse.gh and xh=@xh
END
go

