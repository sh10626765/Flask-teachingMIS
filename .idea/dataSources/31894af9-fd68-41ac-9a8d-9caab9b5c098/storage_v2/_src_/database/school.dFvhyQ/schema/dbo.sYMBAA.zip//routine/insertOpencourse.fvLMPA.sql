-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[insertOpencourse]
	-- Add the parameters for the stored procedure here
	@xq nvarchar(50),
	@kh nchar(10),
	@gh nchar(10),
	@sksj nvarchar(50),
	@rl int
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
	insert dbo.opencourse(xq,kh,gh,sksj,rl,xkrs)
	values(@xq,@kh,@gh,@sksj,@rl,0)
END
go

