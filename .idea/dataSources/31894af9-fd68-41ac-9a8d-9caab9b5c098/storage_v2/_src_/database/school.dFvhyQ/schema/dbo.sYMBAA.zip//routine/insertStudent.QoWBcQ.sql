-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE insertStudent
	-- Add the parameters for the stored procedure here
	@xh nchar(10),
	@xm nchar(10),
	@xb nchar(10),
	@jg nchar(10),
	@yxh nchar(10),
	@pwd nchar(10),
	@sjhm nvarchar(50),
	@csrq datetime
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
	insert dbo.student(xh,xm,xb,jg,yxh,pwd,sjhm,csrq)
	values(@xh,@xm,@xb,@jg,@yxh,@pwd,@sjhm,@csrq)
END
go

